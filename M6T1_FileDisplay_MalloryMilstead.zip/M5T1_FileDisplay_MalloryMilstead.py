# Displaying a file in Python
# 7/10/2017
# CTI-110 M5T1 - File Display
# Mallory Milstead
#

#Open the file.
myfile = open('numbers.txt', 'r')

#Read and display the contents of the file.
for line in myfile:
    number = int(line)
    print(number)

#Close the file.
myfile.close()
